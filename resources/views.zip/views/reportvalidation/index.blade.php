@extends('layouts.app')

@section('content')
    <h3 class="page-title vlaislsek">Report Validation</h3>

      {!! Form::open(['method' => 'POST', 'route' => ['reportvalidation.store'], 'id' => 'validform', 'onsubmit' =>"return fmsvalidation()"]) !!}
    <div class="panel panel-default settingsites">
       

        <div class="panel-body reportindes">
         
          <?php // echo "<pre>"; print_r($formfields);"</pre>";
		  
		//  echo $url."RRRRRRRRRR"; ?>
          
                   <div class="dlyrep-select reporttype">
					{!! Form::label('dailycat1', 'Sites:', ['class' => 'control-label']) !!}
                    {!! Form::select('site', $sites_names, $siteselected, ['class' => 'form-control', 'id' => 'site_id']) !!}				
					</div>
                     
                    <div class="dlyrep-select reporttypelabel">
					{!! Form::label('dailycat1', 'Type:', ['class' => 'control-label']) !!}
                    {!! Form::select('type', $client_statuses, $typeselected, ['class' => 'form-control', 'id' => 'rptype']) !!}				
					</div>
					
					<?php $year1 = Request::segment(4); 
						  if($year1) $year1 = $year1;
						  else $year1 = date('Y');
						  $month1 = Request::segment(5);
						  if($month1) $month1 = $month1;
						  else $month1 = date('m');
						  
						  $year = date('Y');						  
						  $month = date('m');
						  $dayval = date('d');
					?>
                    
                   <div class="reportvalidation-year-selection" style="display:<?php if(Request::segment(3)=='5') echo 'block'; else echo 'none';  ?>">
					<div class="yearlabel">Year:</div>
                    <div class="sleectvalisyear"><select name='valid_year' id="valid_year" class="form-control"> 
                         <option value="">Select Year</option>
						 <?php for($i=2018;$i<=2030;$i++){ ?>
						 <option value="<?php echo $i; ?>" <?php if($year1 == $i) echo 'Selected';?>><?php echo $i; ?></option>
						 <?php } ?>
					</select> </div>
                    </div>
					
					
                    <div class="reportvalidation-month-selection"  
					style="display:<?php if(Request::segment(3)=='5') echo 'block'; else echo 'none';  ?>">
						<div class="monthlabel">Month:</div> 
                      <div class="tantodec">
                       <select name='valid_month' id="valid_month" class="form-control">  
                         <option value="">Select Month</option>
						 <option value="1" <?php if($month1 == "1") echo 'Selected';?>>Jan</option>
						 <option value="2" <?php if($month1 == "2") echo 'Selected';?>>Feb</option>
						 <option value="3" <?php if($month1 == "3") echo 'Selected';?>>Mar</option>
						 <option value="4" <?php if($month1 == "4") echo 'Selected';?>>April</option>
						 <option value="5" <?php if($month1 == "5") echo 'Selected';?>>May</option>
						 <option value="6" <?php if($month1 == "6") echo 'Selected';?>>June</option>
						 <option value="7" <?php if($month1 == "7") echo 'Selected';?>>July</option>
						 <option value="8" <?php if($month1 == "8") echo 'Selected';?>>Aug</option>
						 <option value="9" <?php if($month1 == "9") echo 'Selected';?>>Sept</option>
						 <option value="10" <?php if($month1 == "10") echo 'Selected';?>>Oct</option>
						 <option value="11" <?php if($month1 == "11") echo 'Selected';?>>Nov</option>
						 <option value="12" <?php if($month1 == "12") echo 'Selected';?>>Dec</option>
					</select> 
					</div>
				 </div>
                    
                     @if($typecat == '1')
                     	@include('validationtemplates.firesaftytemplate')
                     @elseif($typecat == '2')
                     	@include('validationtemplates.fpmtemplate')
                     @elseif($typecat == '3')
                     	@include('validationtemplates.pmstemplate')
                     @elseif($typecat == '4')
                     	@include('validationtemplates.securirytemplate')
                      @elseif($typecat == '5')
                     	@include('reportvalidation.summary')
                     @endif	
        
           
          
        </div>
    </div>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript">
function fmsvalidation()
{
	var flag = 0;
	$("input.ereq,select.ereq").each(function(){
		var s = $(this).attr('name');
		if (($(this).val())== ""){
			console.log("One"+s);
			$(this).addClass("error");
			flag = flag+1;
		}
		else
		{
			$(this).removeClass("error");
		}  
	});
	if(flag>0) { 
		alert("All Fields Required");
		$("html, body").animate({ scrollTop: 0 }, "slow");
 		return false;
	}
	else {
		alert("Success");
		return true;
	}
}
$( document ).ready(function() {
  $( "#rptype" ).change(function() 
  {
 
   var val = $(this).val();
   if(val==5)
   {
   		$(".reportvalidation-year-selection").show();
		$(".reportvalidation-month-selection").show();
   }
   else
   {
   		$(".reportvalidation-year-selection").hide();
		$(".reportvalidation-month-selection").hide();
   }
  
   //var href = window.location.href;
   //window.location = href.replace(/getdailyreport\/.*$/, "");
  // window.location.href = "http://aparna.greaterkakinada.com/getdailyreport/"+val;
  // window.location.replace('getdailyreport/'+val);
	//alert("test");
	var site = "";
	var  rtype = "";
	site =   $("#site_id").val();
	rtype =   $("#rptype").val();
	var mon =   $("#valid_month").val();
	var yea =   $("#valid_year").val();
	//alert(site);
	if(site == ""){
	  alert("Please select Site");
	} else if(site != "" && rtype != ""){
	  var href = window.location.href;
	  window.location.href = "/reportdetailfrom/"+site+"/"+rtype+"/"+yea+"/"+mon; 
	}
	
	

  });
  
  $( "#site_id" ).change(function() 
  {
	var site = "";
	var  rtype = "";
	site =   $("#site_id").val();
	rtype =   $("#rptype").val();
    var mon =   $("#valid_month").val();
	var yea =   $("#valid_year").val();
	//alert(site);
	if(site == ""){
	  alert("Please select Site");
	}
	else if(rtype == ""){
	  alert("Please select Type");
	}
	 else if(site != "" && rtype != ""){
	  var href = window.location.href;
     // window.location.href = "/reportdetailfrom/"+site+"/"+rtype;  
	   window.location.href = "/reportdetailfrom/"+site+"/"+rtype+"/"+yea+"/"+mon;  
	  //alert("http://aparna.greaterkakinada.com/reportdetailfrom"+site+"/"+rtype);
	}
  });
  
  $("#valid_year").change(function() 
  {
	var site = "";
	var  rtype = "";
	site =   $("#site_id").val();
	rtype =   $("#rptype").val();
    var mon =   $("#valid_month").val();
	var yea =   $("#valid_year").val();
	//alert(site);
	if(site == ""){
	  //alert("Please select Site");
	} else if(site != "" && rtype != ""){
	  var href = window.location.href;
     // window.location.href = "/reportdetailfrom/"+site+"/"+rtype;  
	   window.location.href = "/reportdetailfrom/"+site+"/"+rtype+"/"+yea+"/"+mon;  
	  //alert("http://aparna.greaterkakinada.com/reportdetailfrom"+site+"/"+rtype);
	}
  });
  
  $( "#valid_month" ).change(function() 
  {
	var site = "";
	var  rtype = "";
	site =   $("#site_id").val();
	rtype =   $("#rptype").val();
    var mon =   $("#valid_month").val();
	var yea =   $("#valid_year").val();
	//alert(site);
	if(site == ""){
	  //alert("Please select Site");
	} else if(site != "" && rtype != ""){
	  var href = window.location.href;
     // window.location.href = "/reportdetailfrom/"+site+"/"+rtype;  
	   window.location.href = "/reportdetailfrom/"+site+"/"+rtype+"/"+yea+"/"+mon;  
	  //alert("http://aparna.greaterkakinada.com/reportdetailfrom"+site+"/"+rtype);
	}
  });
  
  /*$('select[name="sites"]').on('change', function(){    
    //alert($(this).val());   
	
	 var val = $(this).val();
	 
	  if(val == "") {
	  var href = window.location.href;
   //window.location = href.replace(/getdailyreport\/.*$/, "");
   window.location.href = "http://aparna.greaterkakinada.com/dailyreports";  
	   
	 } else {
 //  alert(val);
   var href = window.location.href;
   //window.location = href.replace(/getdailyreport\/.*$/, "");
   //window.location.href = "http://report.local/getdailyreportdetail";
      window.location.href = "http://aparna.greaterkakinada.com/getdailyreportdetail/"+val; 
	  }
  // window.location.replace('getdailyreport/'+val);
	//alert(id); 
});*/

    $("#resetall").click(function(){  
		//$('#validform').reset();
		//alert("clickedreset");
		//document.getElementById("validform").reset();
		$(".resetval").val("");
    }); 


}); 
  
  </script>
  
  @include('partials.footer')
  
  @stop



