{!! Form::label('emp', 'Sub Category', ['class' => 'control-label']) !!}
{!! Form::select('itemsubcategory', $catList, '', ['class' => 'form-control select2mes','id'=>'sub_cats']) !!}