{!! Form::label('asset_id', 'Asset', ['class' => 'control-label']) !!}
{!! Form::select('asset_id', $assetList, '', ['class' => 'form-control select2mes','id'=>'asset_id']) !!}