@extends('layouts.app')

@section('content')
   <!-- <h3 class="page-title">Categories</h3>-->

   

    <div class="panel panel-default respositroy-view asset-type-index">
        <div class="panel-heading assettype-heading">
            Asset Types
             <p class="ptag">
              <a href="{{ route('assetcat-types.index') }}" class="btn btn-new">Asset Category Types</a>
              <a href="{{ route('asset-types.create') }}" class="btn btn-new">Add</a>
    </p>
        </div>

        <div class="panel-body asset-type asset-index-padding">
            <table class="table table-bordered table-striped hall-maekee {{ count($category) > 0 ? 'datatable' : '' }} dt-select">
                <thead class="head-color">
                    <tr>
                        <th style="text-align:center;"><input type="checkbox" id="select-all" /></th>
                        <th>Name</th>
						 <th>Code</th>
                         <th>Prefix</th>
                        <th>Action</th>
                    </tr>
                </thead>
                  
                <tbody>
                    @if (count($category) > 0)
                        @foreach ($category as $client_status)
                            <tr data-entry-id="{{ $client_status->id }}">
                                <td></td>
                                <td>{{ $client_status->name }}</td>
								<td>{{ $client_status->ccode }}</td>
                                <td>{{ $client_status->prefix }}</td>
                                <td><a href="{{ route('asset-types.edit',[$client_status->id]) }}" class="btn btn-xs btn-inverse">Edit</a>{!! Form::open(array(
                'style' => 'display: inline-block;',
                'method' => 'DELETE',
                'onsubmit' => "return confirm('".trans("Are you sure?")."');",
                'route' => ['asset-types.destroy', $client_status->id])) !!}
    {!! Form::submit('Delete', array('class' => 'btn btn-xs btn-danger')) !!}
    {!! Form::close() !!}</td> 
                            </tr>
                        @endforeach
                    @else
                        <tr>  
                            <td colspan="4">No entries in table</td>
                        </tr>
                    @endif
                </tbody> 
            </table>
        </div>
    </div>
     @include('partials.footer')
@stop

@section('javascript')
    <script>
        window.route_mass_crud_entries_destroy = '{{ route('asset-types.mass_destroy') }}';
    </script>
@endsection