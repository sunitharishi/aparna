@extends('layouts.appnew')
@section('content')
<div class="body">
	tet123
</div>

@include('partials.footer')
@stop