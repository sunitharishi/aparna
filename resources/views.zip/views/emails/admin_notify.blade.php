<div style="width:100%;height:100%;margin:0px;padding:0px">

<div style="width:100%;height:100%;margin:0px;padding:0px">

	<div>

        <a href="https://apmspl.com/" target="_blank"><img src="https://apmspl.com/wp-content/uploads/2018/09/APMS_Logo_b-1-2.png" alt="" style="width:200px"></a>  

    </div>

    <div><p style="margin:5px"></p></div>

    <div style="font-family:Arial,Helvetica,sans-serif"><p style="margin:5px;font-size:14px;color:red;line-height:50px">This is a system-generated e-mail. Please do not reply to this e-mail.</p></div>

    <div style="font-family:Arial,Helvetica,sans-serif"><p style="margin:5px;font-size:14px;line-height:50px">Date: <b><?php echo $date; ?></b></p></div>

    <?php if($fmstext!=""){ ?><div style="font-family:Arial,Helvetica,sans-serif"><p style="margin:5px;font-size:14px"><?php echo $fmstext; ?></div><?php } ?>

    <?php if($pmstext!=""){ ?><div style="font-family:Arial,Helvetica,sans-serif"><p style="margin:5px;font-size:14px"><?php echo $pmstext; ?></div><?php } ?>

    <?php if($firesafetext!=""){ ?><div style="font-family:Arial,Helvetica,sans-serif"><p style="margin:5px;font-size:14px"><?php echo $firesafetext; ?></div><?php } ?>

    <?php if($securetext!=""){ ?><div style="font-family:Arial,Helvetica,sans-serif"><p style="margin:5px;font-size:14px"><?php echo $securetext; ?></div><?php } ?>

    <div style="text-align:center;font-family:Arial,Helvetica,sans-serif"><h2>Thank you for watching!</h2></div>

    <div style="font-family:Arial,Helvetica,sans-serif"><p style="margin:5px;font-size:14px"><b>For any queries or technical support please contact below</b></p></div>    

    <div><p></p></div>

    <div style="color:rgba(118,146,60,1);font-family:Arial,Helvetica,sans-serif"><p>T. Arun Kumar - 9502826126</p></div>

    <div style="color:rgba(118,146,60,1);font-family:Arial,Helvetica,sans-serif"><p>B. Naveen Teja - 8340998383</p></div>

    <div><p></p></div>

	

    <?php /*?><div style="font-family:Arial,Helvetica,sans-serif"><p style="margin:5px 5px 10px 5px"><b>Management:</b></p></div>

    <div style="color:rgba(118,146,60,1);font-family:Arial,Helvetica,sans-serif"><p>B. Ambikprasad  -  ambikaprasad@apmspl.com</p></div>

    <div style="color:rgba(118,146,60,1);font-family:Arial,Helvetica,sans-serif"><p>P. Pavankumar  - pavankumarpms@apmspl.com</p></div>

    <div style="color:rgba(118,146,60,1);font-family:Arial,Helvetica,sans-serif"><p>K. V. N. Madhu -  madhu-facilities@apmspl.com</p></div>

    <div><p></p></div><?php */?>

    

    <div style="background:#cccccc;padding:20px;color:#000000;font-weight:bold;font-family:Arial,Helvetica,sans-serif;clear:both;display:block"><p style="margin:5px;font-size:14px">#301 Door no: 6-3-352/2&amp;3,<br>Astral Heights, Road No.1,<br>Banjara Hills,<br>Hyderabad - 500 034.</p></div>

</div>

</div>

