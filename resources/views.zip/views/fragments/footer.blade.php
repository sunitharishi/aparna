<footer class="footer">

      <div class="container">

      	<div class="col-sm-6 float-left">

        	Copy Right &copy;2018. All Rights Reserved

        </div>

      	<div class="col-sm-6 float-right" style="text-align:right;">

        	<a href="http://zonup.com/" target="_blank" style="color:#CCCCCC;">Developed by Zonup</a>

        </div>

      </div>

    </footer>