@extends('layouts.app')

@section('content')
  
<div class="panel panel-default critical-manpower">
    <div class="col-sm-12">
        <div class="enginnering-heading">
        	<h3><span>Major Activities Carried Out</span></h3>
        </div>
    </div>      
    <div class="row eservices-page">
       <div class="col-sm-12">
       		<div class="list-services tickimage1">
            	<ul>
                	<li>long Tennis and basket ball court flood lights fused replaced</li>
                    <li>AB & L- Block Bore well checked along with vendor  vehicle and AB-block problem rectified.</li>
                    <li>All shafts DG sensing controller encloser box covers fixed properly.</li>
                    <li>O-Block DG sets and E Block MCC PLCC ups checked.</li>
                    <li>STP Centrifuge servicing done by revolve team. </li>
                </ul>
            </div>
       </div>
    </div>
</div>

   
    @include('partials.footer')
@stop

