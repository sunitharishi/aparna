@extends('layouts.app')

@section('content')
  
<div class="panel panel-default critical-manpower">
    <div class="col-sm-12">
        <div class="enginnering-heading keyapprovals-heading">
        	<h3><span>Key Approvals Required From Society</span></h3>
        </div>
    </div>      
    <div class="col-sm-12 eservices-page">
       <div class="col-sm-12">
       		<div class="list-services tickimage">
            	<ul>
                	<li>Nil</li>
                   
                </ul>
            </div>
       </div>
    </div>
</div>

   
    @include('partials.footer')
@stop

