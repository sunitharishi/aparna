@extends('layouts.app')

@section('content')
  
<div class="panel panel-default critical-manpower">
    <div class="col-sm-12">
        <div class="enginnering-heading activitiesgardening-heading">
        	<h3><span>Major Activities Carried Out In Housekeeping and Gardening</span></h3>
        </div>
    </div>      
    <div class="row eservices-page">
       <div class="col-sm-12">
       		<div class="list-services tickimage1">
            	<ul>
                	<li>Solar fencing unwanted branches cutting done.</li>
                    <li>All garden drain chambers cleaned.</li>
                    <li>Broken garden sprinkler replaced and cleaned all sprinkler.</li>
                    <li>Drip line flush out done.</li>
                </ul>
            </div>
       </div>
    </div>
</div>

   
    @include('partials.footer')
@stop

