

<!DOCTYPE html>

<html lang="en">

  <head>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <!-- Meta, title, CSS, favicons, etc. -->

    <meta charset="utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">



    <title>MMR Index</title>

    <style>

	  *

	  {

	  font-family:Arial, Helvetica, sans-serif;

	  }

.aparna-logo
{

 background-color:#0157a4;

 position:absolute;

 right:0px;

 top:-20px;

 padding:4px;

 width:110px;

 height:auto;

}
.enginnering-heading
{
    margin-bottom:20px;
}
.enginnering-heading h2

{

 font-size: 18px;

    font-weight: 600;

    color: #666262;

    text-align: center;

	margin-bottom:0px;

text-transform:uppercase;

}

.body-tage

{

 position:relative;

}

.footer

{

 font-weight:100;

 font-size:16px !important;

 text-align:right;

 position:absolute;

 bottom:-80px;

 right:0px;

}

	h4

{

 margin-bottom:10px;

 margin-top:5px;

 line-height:19px;

 padding:0px;

font-size:17px;

}



.main-heading
{
    margin:-8px 0px 10px 0px;
}


	</style>

  </head>





    <div class="panel panel-default critical-manpower">

        <div class="row">

        	<div class="enginnering-heading power-heading">

           		    <h2 class="main-heading">MMR REPORT FOR THE MONTH OF XXXX-XXXX</h2>

                 <img src="images/apms-logo.png" class="aparna-logo" >

           </div>

        </div>      

        <div class="row">

            <h4><span>9. Average Power Consumption EB+DG</span></h4>

        </div>

         <p class="footer">Aparna Property Management Services Pvt.Ltd.,</p>	

    </div>   

	

 </html>




 



