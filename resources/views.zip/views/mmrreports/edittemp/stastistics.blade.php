@extends('layouts.app')

@section('content')
<style>
    .demo-container *
    {
        color:#000;
        font-weight:700 !important;
    }
</style>

<div class="dx-viewport">

    <div class="demo-container">
      <div class="col-sm-6">
            <h3 class="graphs-heading"></h3>
        <div id="chart" class="bar-charts-statistics">
            
        </div> 
      </div>
      <div class="col-sm-6">
           <h3 class="graphs-heading"></h3>
    	<div id="chart2" class="bar-charts-statistics2">    	    
    	</div> 
      </div>
      <div class="col-sm-6">
          <h3></h3>
    	<div id="chart3" class="bar-charts-statistics3"></div>
     </div>
       <div class="col-sm-6">
            <h3></h3>
    	<div id="chart4" class="bar-charts-statistics3"></div>      
       </div>
        <div class="row" id="buttonGroup">

            <div class="row-element" id="export"></div>

        </div>

    </div>

</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

    <script>window.jQuery || document.write(decodeURIComponent('%3Cscript src="js/jquery.min.js"%3E%3C/script%3E'))</script>

    <link rel="stylesheet" type="text/css" href="https://cdn3.devexpress.com/jslib/18.2.6/css/dx.common.css" />

    <link rel="dx-theme" data-theme="generic.light" href="https://cdn3.devexpress.com/jslib/18.2.6/css/dx.light.css" />

    <script src="https://cdn3.devexpress.com/jslib/18.2.6/js/dx.all.js"></script>

	<?php 
	
	
		
	
		$cmonth = $month." ".$year;
		
		$cmonth = date("M",strtotime($year."-".$month."-1"))." ".$year;
		
		$pmonth = date("M",strtotime($pyear."-".$prev_omonth."-1"))." ".$year;
		
		$bpmonth = date("M",strtotime($poyear."-".$prev_tmonth."-1"))." ".$year;
		
		/*
	
		$prev_omonth = date ('m', strtotime ( '-1 month' , strtotime ( $month )));
		
		$pmonth = date("M",strtotime($pyear."-".$prev_omonth."-1"))." ".$pyear;
	
		$prev_tmonth = date ('m', strtotime ( '-2 month' , strtotime ( $month )));
		
		$bpmonth = date("M",strtotime($poyear."-".$prev_tmonth."-1"))." ".$poyear;*/

		$pwrfailure1 =  str_replace(":",".",$pwrfailure1); 

		$pwrfailure2 =  str_replace(":",".",$pwrfailure2); 
		
		$pwrfailure3 =  str_replace(":",".",$pwrfailure3); 

	?>

    <script type="text/javascript">

      var dataSource = [{

      state: "EB Power in units",

      nov2018: <?php echo $pwr_pwrfactor1; ?>,

      dec2018: <?php echo $pwr_pwrfactor2; ?>,

      jan2019: <?php echo $pwr_pwrfactor3; ?>

    }, {

      state: "Solar Power in units",

      nov2018: <?php echo $solarpwrunits1; ?>,

      dec2018: <?php echo $solarpwrunits2; ?>,

      jan2019: <?php echo $solarpwrunits3; ?>

    },  {

      state: "DG Units Generated",

      nov2018: <?php echo $dgunits1; ?>,

      dec2018: <?php echo $dgunits2; ?>,

      jan2019: <?php echo $dgunits3; ?>

    }];

	

	var dataSource1 = [{

      state: "Metro in KL",

      nov2018: <?php echo $wspmetro1; ?>,

      dec2018: <?php echo $wspmetro2; ?>,

      jan2019: <?php echo $wspmetro3; ?>

    }, {

      state: "Bores in KL",

      nov2018: <?php echo $wspbores1; ?>,

      dec2018: <?php echo $wspbores2; ?>,

      jan2019: <?php echo $wspbores3; ?>

    }, {

      state: "Tanker in KL",

      nov2018: <?php echo $wsptankers1; ?>,

      dec2018: <?php echo $wsptankers2; ?>,

      jan2019: <?php echo $wsptankers3; ?>

    }, {

      state: "STP Treated in KL",

      nov2018: <?php echo $treatwater1; ?>,

      dec2018: <?php echo $treatwater2; ?>,

      jan2019: <?php echo $treatwater3; ?>

    }];
	
	
	var dataSource2 = [{

      state: "Power failure hours",

      nov2018: <?php echo $pwrfailure1; ?>,

      dec2018: <?php echo $pwrfailure2; ?>,

      jan2019: <?php echo $pwrfailure3; ?>

    }];

   var dataSource3 = [{

      state: " ",

      nov2018: <?php echo $dieselconsume1; ?>,

      dec2018: <?php echo $dieselconsume2; ?>,

      jan2019: <?php echo $dieselconsume3; ?>

    }];


  </script>

    <script type="text/javascript">

    $(function(){

      var chartInstance = $("#chart").dxChart({

        dataSource: dataSource,

        commonSeriesSettings: {

          argumentField: "state",

          type: "bar",

          hoverMode: "allArgumentPoints",

          selectionMode: "allArgumentPoints",

          label: {

            visible: true,

            format: {

              type: "fixedPoint",

              precision: 0

            }

          }

        },

        series: [

          { valueField: "nov2018", name: "<?php echo $bpmonth; ?>" },

          { valueField: "dec2018", name: "<?php echo $pmonth; ?>" },

          { valueField: "jan2019", name: "<?php echo $cmonth; ?>" }

        ],

        title: "Power Consumption Analysis",

        legend: {

          verticalAlignment: "bottom",

          horizontalAlignment: "center"

        },

        "export": {

          enabled: false,

        

        },

        onPointClick: function (e) {

          e.target.select();

        }

      }).dxChart("instance");

      

      

      var chartInstance1 = $("#chart3").dxChart({

        dataSource: dataSource2,

        commonSeriesSettings: {

          argumentField: "state",

          type: "bar",

          hoverMode: "allArgumentPoints",

          selectionMode: "allArgumentPoints",

          label: {

            visible: true,

            format: {

              type: "fixedPoint",

              precision: 0

            }

          }

        },

        series: [

          { valueField: "nov2018", name: "<?php echo $bpmonth; ?>" },

          { valueField: "dec2018", name: "<?php echo $pmonth; ?>" },

          { valueField: "jan2019", name: "<?php echo $cmonth; ?>" }

        ],

        title: "Power Failure Analysis",

        legend: {

          verticalAlignment: "bottom",

          horizontalAlignment: "center"

        },

        "export": {

          enabled: false,

        

        },

        onPointClick: function (e) {

          e.target.select();

        }

      }).dxChart("instance");

      
	  var chartInstance2 = $("#chart2").dxChart({

        dataSource: dataSource1,

        commonSeriesSettings: {

          argumentField: "state",

          type: "bar",

          hoverMode: "allArgumentPoints",

          selectionMode: "allArgumentPoints",

          label: {

            visible: true,

            format: {

              type: "fixedPoint",

              precision: 0

            }

          }

        },

        series: [

          { valueField: "nov2018", name: "<?php echo $bpmonth; ?>" },

          { valueField: "dec2018", name: "<?php echo $pmonth; ?>" },

          { valueField: "jan2019", name: "<?php echo $cmonth; ?>" }

        ],

        title: "Water Consumption Analysis",

        legend: {

          verticalAlignment: "bottom",

          horizontalAlignment: "center"

        },

        "export": {

          enabled: false,

        

        },

        onPointClick: function (e) {

          e.target.select();

        }

      }).dxChart("instance");

	  
	  var chartInstance3 = $("#chart4").dxChart({

        dataSource: dataSource3,

        commonSeriesSettings: {

          argumentField: "state",

          type: "bar",

          hoverMode: "allArgumentPoints",

          selectionMode: "allArgumentPoints",

          label: {

            visible: true,

            format: {

              type: "fixedPoint",

              precision: 0

            }

          }

        },

        series: [

          { valueField: "nov2018", name: "<?php echo $bpmonth; ?>" },

          { valueField: "dec2018", name: "<?php echo $pmonth; ?>" },

          { valueField: "jan2019", name: "<?php echo $cmonth; ?>" }

        ],

        title: "Diesel Consumption Analysis ",

        legend: {

          verticalAlignment: "bottom",

          horizontalAlignment: "center"

        },

        "export": {

          enabled: false,

        

        },

        onPointClick: function (e) {

          e.target.select();

        }

      }).dxChart("instance");
	  
	  

      $("#export").dxButton({

        icon: "export",

        text: "Export",

        onClick: function() {

          chartInstance.exportTo("PowerConsumption", "png");

          chartInstance1.exportTo("PowerFailure", "png");
		  
		  chartInstance2.exportTo("WaterConsumption", "png");
		  
		  chartInstance3.exportTo("DieselConsumed", "png");

        }

      });

    });

  </script>

@include('partials.footer')

@stop

