@extends('layouts.app')

@section('content')
  
    <div class="panel panel-default respositroy-view maalajljd">
        <div class="row">
           <div class="mmr-indexpage">
           	  <h1>Monthly Management Report</h1> 
              <h4>Aparna Property Management Services Ltd</h4>
              <p>May - <span>2018</span></p>
           </div>
        </div>
        
        
        
        
    </div>

   
    @include('partials.footer')
@stop

