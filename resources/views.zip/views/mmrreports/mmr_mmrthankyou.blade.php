 <!DOCTYPE html>



<html lang="en">



  <head>



    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">



    <!-- Meta, title, CSS, favicons, etc. -->



    <meta charset="utf-8">



    <meta http-equiv="X-UA-Compatible" content="IE=edge">



    <meta name="viewport" content="width=device-width, initial-scale=1">







    <title>MMR Index</title>



    <!-- Bootstrap -->



    <link rel="icon" href="images/ICON.png">



   <!-- <link href="/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">-->



     <!--<link href="/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">-->







    <!-- Custom Theme Style -->



    <link href="/build/css/custom.css" rel="stylesheet">



 <link media="all" type="text/css" rel="stylesheet" href="{{ url('scripts/third/summernote') }}/summernote.css">



<style>



*



{



 font-family:Arial, Helvetica, sans-serif;



}







.body-tage



{



 position:relative;



}

.scope-imag1

{

 width:100%;

 text-align:center;

 margin-bottom:10px;

}

.thank-you

{

 width:100%;

 text-align:center;

 text-transform:uppercase;

 font-size:24px;

 font-weight:700;

 margin:15px 0px;

}

.footer



{



 font-weight:100;



 font-size:16px !important;



 text-align:right;



 position:absolute;



 bottom:-40px;



 right:0px;



}



</style>



<body class="body-tage">



<div class="row">  



    <div class="scope-nature">



         <div class="scope-imag1"><img src="images/mmrreoprts/<?php echo $sitename; ?>-logo.jpg"  style="width:auto;"/></div>



        <div class="scope-imag"><img src="images/mmrreoprts/<?php echo $sitename; ?>.jpg"  style="width:100%;"/></div>



         <div class="thank-you">Thank You</div>



    </div>  



   



     <p class="footer">Aparna Property Management Services Pvt. Ltd.,</p>  



</div>



</body>          



          



</html>







<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>







