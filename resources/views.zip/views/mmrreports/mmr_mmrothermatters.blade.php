@extends('layouts.app')

@section('content')
  
<div class="panel panel-default othermatters-heading">
    <div class="row">
       <h1>Other Matters <br /> &amp; <br /> Key Approvals From Society</h1>
    </div>
</div>

   
    @include('partials.footer')
@stop

