 <!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>MMR Index</title>
    <!-- Bootstrap -->
    <link rel="icon" href="images/ICON.png">
   <!-- <link href="/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">-->
     <!--<link href="/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">-->

    <!-- Custom Theme Style -->
    <link href="/build/css/custom.css" rel="stylesheet">
 <link media="all" type="text/css" rel="stylesheet" href="{{ url('scripts/third/summernote') }}/summernote.css">
<style>
*
{
 font-family:Arial, Helvetica, sans-serif;
}
.mmrreport-eading
{
    margin-bottom:20px;
}
.mmrreport-eading h2
{
 font-size: 18px;
    font-weight: 600;
    color: #666262;
    text-align: center;
	text-transform:uppercase;
}

table
{
 margin:10px 0px;
 border-collapse:collapse;
}
table thead tr th, table tbody tr td
{
 padding:8px;
 font-size:12.6px;
}
.note span
{
 width:auto;
 float:left;
 margin-right:6px;
}
.note div
{
 width:auto;
 float:left;
 font-weight:600;
}
.incident-summary
{
 font-size:17px;
font-weight:600;
}
.aparna-logo
{
 background-color:#0157a4;
 position:absolute;
 right:0px;
 top:-20px;
 padding:4px;
 width:110px;
 height:auto;
}
.body-tage
{
 position:relative;
}
.footer
{
 font-weight:100;
 font-size:16px !important;
 text-align:right;
 position:absolute;
 bottom:-80px;
 right:0px;
}
.soft-services
{
 font-weight:600;
 font-size:17px;
 text-decoration:underline;
}
.main-heading
{
    margin:-8px 0px 10px 0px;
}
</style>

<div class="mmrreport-eading">
   <h2 class="main-heading">MMR REPORT FOR THE MONTH OF {{ $monthname }}-{{ $year }}</h2>
    <img src="images/apms-logo.png" class="aparna-logo" >
</div>


<div class="row">  
    <div class="scope-nature">
    	 <?php if($MICount == 0 && $EQPCOunt == 0) { ?>
	 <div class="soft-services">TECHNICAL SERVICES</div>
	 <?php } ?>
        <?php /*?><div class="incident-summary"><?php echo $tCount; ?>. AMC Tracker</div>
        <table width="100%" border="1">
        	<thead>
            	<tr>
                	<th>Asset</th>
                    <th>Name</th>
                    <th>Vendor</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                </tr>
            </thead>
            <tbody>
             <?php $i = 0; ?> 
            @if(count($resval) > 0)
             @foreach($resval as $k => $val)
            	<tr>
                     <?php $i = $i + 1; ?>
                    <td><?php if(isset($val['assetname'])) echo $val['assetname']; ?></td>
                	<td><?php if(isset($val['name'])) echo $val['name']; ?></td>
                    <td><?php if(isset($val['vendorname'])) echo $val['vendorname']; ?></td>
                    <td style="width:80px;"><?php if(isset($val['amc_startdate'])) echo date("d-m-Y",strtotime($val['amc_startdate'])); ?></td>
                    <td style="width:80px;"><?php if(isset($val['amc_enddate'])) echo date("d-m-Y",strtotime($val['amc_enddate'])); ?></td>
                   
                </tr>
                @endforeach
            @endif   
            </tbody>
        </table>
       
    </div>	<?php */?>
    @if(count($wresval) > 0)
    <div class="incident-summary"><?php echo $tCount; ?>. Warranty/AMC</div>
    <table width="100%" border="1">    		
        	<thead>
            	<tr>
                	<th rowspan="2">Asset Description</th>
                    <th rowspan="2">Capacity / Qty</th>
                    <th rowspan="2">Location</th>
                    <th rowspan="2">Vendor Name</th>
                    <th rowspan="2">PO / WO no.   Date</th>
                    <th colspan="2" align="center">Warranty</th>
                    <th colspan="2" align="center">AMC</th>
                    <th rowspan="2">AMC (Yes/No)</th>
                    <th rowspan="2">Remarks</th>
                </tr>
                <tr>
                	<th align="center">
                    	From
                    </th>
                    <th align="center">
                    	To
                    </th>
                    <th align="center">
                    	From
                    </th>
                    <th align="center">
                    	To
                    </th>
                </tr>
            </thead> 
            <tbody>
             <?php $i = 0; ?> 
             @foreach($wresval as $k => $val)
            	<tr>
                     <?php $i = $i + 1; ?>
                    <td><?php if(isset($val['asset_description'])) echo $val['asset_description']; ?></td>
                	<td><?php if(isset($val['capacity_qty'])) echo $val['capacity_qty']; ?></td>
                    <td><?php if(isset($val['location'])) echo $val['location']; ?></td>
                    <td><?php if(isset($val['vendor_name'])) echo $val['vendor_name']; ?></td>
                    <td><?php if(isset($val['PO/WO'])) echo $val['PO/WO']; ?></td>
                    <td style="width:80px;text-align:center;"><?php if(isset($val['warranty_from']) && $val['warranty_from']!='') echo date("d-m-Y",strtotime($val['warranty_from'])); else echo "-"; ?></td>
                    <td style="width:80px;text-align:center;"><?php if(isset($val['warranty_to']) && $val['warranty_from']!='') echo date("d-m-Y",strtotime($val['warranty_to'])); else echo "-"; ?></td>
                    <td style="width:80px;text-align:center;"><?php if(isset($val['amc_from']) && $val['warranty_from']!='') echo date("d-m-Y",strtotime($val['amc_from'])); else echo "-"; ?></td>
                    <td style="width:80px;text-align:center;"><?php if(isset($val['amc_to']) && $val['warranty_from']!='') echo date("d-m-Y",strtotime($val['amc_to'])); else echo "-"; ?></td>
                    <td><?php if(isset($val['amc_status'])) echo $val['amc_status']; ?></td>
                    <td><?php if(isset($val['remarks'])) echo $val['remarks']; ?></td>
                   
                </tr>
                @endforeach
            </tbody>
        </table>       
    </div>	
    @endif  
    <p class="footer">Aparna Property Management Services Pvt. Ltd.,</p>	 
</div>
					    
					
</html>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

